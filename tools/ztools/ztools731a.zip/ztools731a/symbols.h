
extern void init_symbols(const char *);

extern int print_attribute_name(unsigned long, int);
extern int print_property_name(unsigned long, int);
extern int print_local_name(unsigned long, int);
extern int print_global_name(unsigned long, int);

